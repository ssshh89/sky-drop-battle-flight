# Sky Drop: Battle Flight

A mobile-friendly, Free Fire-inspired arcade flyer built with plain HTML, CSS, and JavaScript. It uses original generic battle-zone styling rather than Free Fire logos or game assets.

## Play locally
Open `index.html` in a modern browser. Tap/click the play area or press Space / Up Arrow / W to flap.

## Deploy to Render
1. Create a new GitHub repository named `sky-drop-battle-flight`.
2. Upload `index.html`, `README.md`, and `render.yaml`.
3. In Render, choose **New + → Static Site** and connect that repository.
4. Use the `main` branch, leave Build Command blank, and set Publish Directory to `.`.
5. Click **Create Static Site**. Render will publish the game to an `onrender.com` URL.

The included `render.yaml` is an optional Blueprint configuration.
